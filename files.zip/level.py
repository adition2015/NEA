import pygame
from player import Player
from enemy import Enemy
from settings import *
from utils import draw_debug
from grid_waypoint import *
from pathfinding import distance, a_star
# Links:
"https://www.youtube.com/watch?v=UT_tKPLejyU" # pygame layers for drawing on screen


def scale_rect(x, y, w, h):
    return (
        int(x * settings.scale_x),
        int(y * settings.scale_y),
        int(w * settings.scale_x),
        int(h * settings.scale_y)
    )

class Level:
    def __init__(self, ID, data):
        player_pos = tuple(x//2 for x in settings.level_res)
        self.ID = ID

        self.surface = pygame.Surface(settings.level_res, pygame.SRCALPHA)
        self.walls = []
        self.doors = []
        self._load_level(data)

        self.collision_rects = [wall.rect for wall in self.walls]
        self.static_rects = self.collision_rects.copy()
        self.interactables = [door for door in self.doors]
        self.door_rects = [door.rect for door in self.doors]

        self.graph = WaypointGraph(settings.level_res, self.static_rects, int(50*settings.scale_diagonal), int(10*settings.scale_diagonal), self.door_rects)
        connected = [wp for wp in self.graph.waypoints if wp.neighbours]
        print(f"Waypoints with neighbours: {len(connected)} / {len(self.graph.waypoints)}")

        for door in self.doors:
            door.interact(self.collision_rects)

        self.player = Player(
                             position=pygame.Vector2(player_pos),
                             direction=pygame.Vector2(0, -1)
                             )

        self.enemies = [
            Enemy((100, 100), (0, 0), [(100, 100), (100, 200), (200, 100), (400, 400)]),
            Enemy((600, 600), (0, 0), [(600, 600), (400, 600), (800, 100), (400, 100)])
            #Enemy((200, 200), (0, 0), [(200, 200), (300, 200), (200, 600), (900, 400)]),
            #Enemy((500, 600), (0, 0), [(500, 600), (200, 100), (700, 100), (100, 500)])
        ]

        self.precalculate_patrol_path()

        self.cone_surface = pygame.Surface(settings.level_res).convert()
        self.cone_temp = pygame.Surface(settings.level_res).convert()
        self.cone_update_interval = 50  # ms between cone redraws (= 20 FPS)
        self.cone_timer = 0

    def update(self, dt):
        self.cone_timer += dt * 1000
        self.player.update(dt)
        self._resolve_collisions()
        self.handle_interaction()
        self.check_enemy_interactions()
        self.update_vision_cones()
        for i in self.enemies:
            i.update(dt)

    def draw(self, screen, fps):
        self.surface.fill((20, 20, 20))

        for i in self.doors:
            i.draw(self.surface)

        self.player.draw(self.surface)

        for i in self.enemies:
            i.draw(self.surface)
        if self.cone_timer >= self.cone_update_interval:
            self.draw_vision_cones()
            self.cone_timer = 0
        self.surface.blit(self.cone_surface, (0, 0), special_flags=pygame.BLEND_ADD)

        for i in self.walls:
            i.draw(self.surface)

        draw_debug(screen, {
            "pos":   self.enemies[0].position,
            "movement_mode": self.player.movement_mode,
            "fps": round(fps),
            "enemy_state" : self.enemies[1].state
        })

        for wp in self.graph.waypoints:
            wp.draw(self.surface)

        # debug collision rects:
        #for rect in self.collision_rects:
        #   pygame.draw.rect(self.surface, (0, 255, 0), rect, 2)

        screen.blit(self.surface, settings.level_offset)

    def _load_level(self, data: dict):
        for (x, y, w, h) in data.get("walls", []):
            self.walls.append(Wall(*scale_rect(x, y, w, h)))

        for (x, y, o) in data.get("doors", []):
            sx, sy = int(x * settings.scale_x), int(y * settings.scale_y)
            self.doors.append(Door(sx, sy, o))

    def check_interaction(self):
        if self.player.interact_signal == True:
            target_candidates = {}
            for i in self.interactables:
                distance_vec = self.player.position - i.rect.center
                if distance_vec.magnitude() <= 50:
                    target_candidates[i] = distance_vec.magnitude()
            if len(target_candidates) > 0:
                key = min(target_candidates, key=target_candidates.get)
                self.player.interact_signal = False
                return key

    def check_enemy_interactions(self):
        for enemy in self.enemies:
            for door in self.doors:
                dist = pygame.Vector2(door.rect.center).distance_to(enemy.position)
                if dist < 40 and not door.is_open:
                    door.interact(self.collision_rects)
                elif dist > 50 and dist < 60 and door.is_open:
                    door.interact(self.collision_rects)

    def check_player_LoS(self, enemy):
        if len(enemy.vision_points) < 3:
            return False
        return self._point_in_polygon(self.player.position, enemy.vision_points)

    def _point_in_polygon(self, point: pygame.Vector2, polygon: list) -> bool:
        """Ray casting algorithm — counts how many polygon edges a ray crosses."""
        x, y = point
        inside = False
        n = len(polygon)
        j = n - 1
        for i in range(n):
            xi, yi = polygon[i]
            xj, yj = polygon[j]
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                inside = not inside
            j = i
        return inside

    def update_vision_cones(self):
        for enemy in self.enemies:
            if self.check_player_LoS(enemy):
                # Player is visible — pass the live position; transition_chase
                # updates last_seen only here, so it's always the real sighting.
                enemy.transition_chase(self.player.position)
            elif enemy.state == "chase":
                # LoS just broke while chasing — compute A* path to last_seen
                # and hand it to the enemy to begin the search phase.
                search_path = self._compute_search_path(enemy)
                enemy.transition_search(search_path)
            # "patrol" or "search" with no LoS: do nothing.
            # The enemy calls transition_patrol() itself when the search
            # path is exhausted without re-acquiring the player.

    def _compute_search_path(self, enemy) -> list:
        """
        A* from the enemy's current position to its last confirmed player
        sighting. Returns a list[Vector2] or [] if pathfinding fails.
        Lives here because only Level has access to the waypoint graph.
        """
        if enemy.last_seen is None:
            return []
        start_wp = self.graph.nearest_waypoint(enemy.position)
        end_wp   = self.graph.nearest_waypoint(enemy.last_seen)
        path = a_star(start_wp, end_wp)
        return path if path else []

    def handle_interaction(self):
        interactable = self.check_interaction()
        if interactable:
            interactable.interact(self.collision_rects)

    def handle_input(self, event):
        self.player.handle_input(event)

    def _resolve_collisions(self):
        for rect in self.collision_rects:
            if self.player.rect.colliderect(rect):
                offset = self._calculate_pushout(self.player.rect, rect)
                self.player.resolve_collision(offset)
        for rect in self.collision_rects:
            for enemy in self.enemies:
                if abs(rect.centerx - enemy.rect.centerx) > 80:
                    continue
                if enemy.rect.colliderect(rect):
                    offset = self._calculate_pushout(enemy.rect, rect)
                    enemy.resolve_collision(offset)

    def _calculate_pushout(self, player_rect: pygame.Rect, wall_rect: pygame.Rect):
        overlap_left   = wall_rect.right  - player_rect.left
        overlap_right  = player_rect.right - wall_rect.left
        overlap_top    = wall_rect.bottom - player_rect.top
        overlap_bottom = player_rect.bottom - wall_rect.top

        min_x = overlap_left  if overlap_left  < overlap_right  else -overlap_right
        min_y = overlap_top   if overlap_top   < overlap_bottom else -overlap_bottom

        if abs(min_x) < abs(min_y):
            return pygame.Vector2(min_x, 0)
        else:
            return pygame.Vector2(0, min_y)

    def precalculate_patrol_path(self):
        for enemy in self.enemies:
            enemy.waypoints = []
            for i in enemy.patrol_points:
                enemy.waypoints.append(self.graph.nearest_waypoint(i))
            enemy.precalculate_patrol_path()
            enemy.set_direction(enemy.patrol_path[enemy.patrol_ID])

    def draw_vision_cones(self):
        self.cone_surface.fill((0, 0, 0))
        for enemy in self.enemies:
            enemy.vision_points = enemy.build_vision_cone(self.collision_rects)
            if len(enemy.vision_points) >= 3:
                self.cone_temp.fill((0, 0, 0))
                pygame.draw.polygon(self.cone_temp, enemy.vision_cone_colour, enemy.vision_points)
                self.cone_surface.blit(self.cone_temp, (0, 0),
                                       special_flags=pygame.BLEND_ADD)


# fix nav polygon so that it takes points in order that are connected then form a polygon

class Wall:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = self.build_wall()

    def build_wall(self):
        return pygame.rect.Rect(self.x, self.y, self.width, self.height)

    def draw(self, surface):
        pygame.draw.rect(surface, (255, 255, 255), self.rect)

class Door:
    def __init__(self, x, y, o: int):
        self.is_open = True
        self.width = 5 if o == 0 else 50
        self.height = 50 if o == 0 else 5
        self.width *= settings.scale_x
        self.height *= settings.scale_y
        self.rect = pygame.rect.Rect(x, y, self.width, self.height)

    def open(self, collision_rects):
        if not self.is_open:
            self.is_open = True
            try:
                collision_rects.remove(self.rect)
            except ValueError:
                print("Door not added to collision_rects")
            return collision_rects

    def close(self, collision_rects):
        if self.is_open:
            self.is_open = False
            collision_rects.append(self.rect)
            return collision_rects

    def interact(self, collision_rects):
        if self.is_open:
            self.close(collision_rects)
        else:
            self.open(collision_rects)

    def draw(self, surface):
        colour = (113, 93, 76) if self.is_open else (75, 57, 41)
        pygame.draw.rect(surface, colour, self.rect)
